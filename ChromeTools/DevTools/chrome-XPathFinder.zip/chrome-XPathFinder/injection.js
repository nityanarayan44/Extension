function test(obj) {
    console.log("Passed Param >>> ");
    console.log(obj);
    alert('I called by some one [devtools]');
    return true;
}
