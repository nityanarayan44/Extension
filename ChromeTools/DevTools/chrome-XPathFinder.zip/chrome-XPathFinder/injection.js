/*
 * @Author: Ashutosh Mishra, NNG Experiments.
 * @Version 1
 * @XPath Finder
 * @Started 25 AUG 2017
 * @Modified 08 Nov 2017 [Prototype-C]
 * @license : MIT License 2017
 * Use of this source code is open
 **/
function test(obj) {
    console.log("Passed Param >>> ");
    console.log(obj);
    alert('I called by some one [devtools]');
    return true;
}
