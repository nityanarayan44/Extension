# ReadMe
===================================================

# How to Use this DevTool Extension
- Install the devtool extension
    - Type "chrome://extensions" on your address bar
    - Enable "Developer Mode" by checking the Developer Mode checkbox
    - Click on "Load Unpacked Extension", a Browse Folder window will appear
    - Choose this chrome-XPathFinder folder (After extraction of ZIP file)
    - If all goes well, you will see new Extension added on the top of the current list.
    
- Press "F12" on your chrome bowser to open the DeveloperTools
- Select "Elements" panel,
- In "Elements" panel there is a sidebar, Select "XPATH FINDER" sidebar panel.
- Now Click or press "Ctrl+Shift+C" to inspect an element
- All the required data for xpath, you will see in the "XPATH FINDER" sidebar panel.


# Refer this image for better understanding
![Image for devtool extension understanding](Core_01.png "devtool extension")
